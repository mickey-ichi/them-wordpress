=== Megashop ===

Author: TemplateTrip
Tags: one-column, two-columns, Both-sidebar, right-sidebar, accessibility-ready, custom-background, custom-colors, custom-header, custom-menu, editor-style, featured-images, flexible-header, post-formats, rtl-language-support, sticky-post, threaded-comments, translation-ready, blog,Mega Stores, Layout, Electronics, Fashion, Auto, automotive, tools, parts, Furniture, art, home, decor, crafts, Gift, Flowers, Organic, Grocery, Wine, bakery, food, gusto, drinks, mega, lingerie, Beauty, cosmetics, Jewelry, accessories, cloths, Blog, accessories, minimal, multipurpose store

Requires at least: 4.4
Tested up to: 4.7
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Megashop WooCommerce Multipurpose Responsive Theme.

== Description ==

Megashop WooCommerce Multipurpose Responsive Theme is specialized for Mega Stores, Layout, Electronics, Fashion, Auto, automotive, tools, parts, Furniture, art, home, decor, crafts, Gift, Flowers, Organic, Grocery, Wine, bakery, food, gusto, drinks, mega, lingerie, Beauty, cosmetics, Jewelry, accessories, cloths, Blog, accessories, minimal and multipurpose store. Mega Shop Layouts are looking good with its colors combination and included 8+ different Layouts. It is very clean and looks professional.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Changelog ==

April 17, 2017
- Just fixed "WooCommerce Template Overrides Out Of Date" issue to support with latest version of WooCommerce 3.x
April 09, 2017
- Added 6 more Layouts (Books, Bio-Harbel, Pet-Food, Medicine, Beauty-Cosmetics, Tools-Equipment)
March 09, 2017
- Initial Release